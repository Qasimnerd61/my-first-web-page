﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
    public partial class Customers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("Login.aspx");
        }

        [WebMethod]

        public static string GetCustomers()
        {
            List<Customer> list = (List<Customer>)HttpContext.Current.Session["Customer"];

            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }

        [WebMethod]
        public static string EditCustomers(string id, string name, string address)
        {
            List<Customer> list = (List<Customer>)HttpContext.Current.Session["Customer"];
            int ID = Convert.ToInt32(id);

            for (int i = 0; i < list.Count; i++)
            {
                if (ID == list[i].ID)
                {
                    if (name != "")
                    {
                        list[i].Name = name;
                    }
                    if (address != "")
                    {
                        list[i].Address = address;
                    }
                }
            }
            JavaScriptSerializer js1 = new JavaScriptSerializer();
            HttpContext.Current.Session["Customer"] = list;
            return js1.Serialize(list);
        }

        [WebMethod]
        public static string ClearCustomer(string id)
        {
            List<Customer> list = (List<Customer>)HttpContext.Current.Session["Customer"];
            int ID = Convert.ToInt32(id);


            for (int i = 0; i < list.Count; i++)
            {
                if (ID == list[i].ID)
                {
                    list.Remove(list[i]);
                }
            }

            JavaScriptSerializer js3 = new JavaScriptSerializer();
            HttpContext.Current.Session["Customer"] = list;
            return js3.Serialize(list);
        }
        [WebMethod]
        public static string AddCustomer(string id, string name, string address)
        {
            List<Customer> list = (List<Customer>)HttpContext.Current.Session["Customer"];
            int ID = Convert.ToInt32(id);
            

            Customer newCustomer = new Customer(ID, name, address);
            list.Add(newCustomer);
            JavaScriptSerializer js2 = new JavaScriptSerializer();
            HttpContext.Current.Session["Customer"] = list;
            return js2.Serialize(list);
        }
    }

}