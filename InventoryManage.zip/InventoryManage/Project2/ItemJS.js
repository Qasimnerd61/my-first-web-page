﻿$(document).ready(function () {

    $.ajax({
        url: 'Items.aspx/GetItems',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (data) {

            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'itemID'},
                    { 'data': 'itemName' },
                    { 'data': 'costPrice' },
                    { 'data': 'salePrice' },
                    { 'data': 'itemID',
                      'render': function (data) {
                          return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editItem(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearItem(' + data + ')"><i class="fa fa-trash"></i></button>'
                        }
                    }
                ]
            });
        }

    });


});
function editItem(id) {

    var inputName = document.createElement("input");
    inputName.setAttribute("type", "text");
    inputName.setAttribute("id", "inputName");

    var inputCost = document.createElement("input");
    inputCost.setAttribute("type", "number");
    inputCost.setAttribute("id", "inputCost");

    var inputSale = document.createElement("input");
    inputSale.setAttribute("type", "number");
    inputSale.setAttribute("id", "inputSale");

    for (let i = 0; i < myTable.rows.length; i++) {

        var x = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == x) {

            document.getElementById("myTable").rows[i].cells[1].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[1].appendChild(inputName);

            document.getElementById("myTable").rows[i].cells[2].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[2].appendChild(inputCost);

            document.getElementById("myTable").rows[i].cells[3].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[3].appendChild(inputSale);

            document.getElementById("myTable").rows[i].cells[4].innerHTML = "";
            var y2 = '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="updateList(' + x + ')">Update</button> <button class="btn btn-primary" id="cancel" >Cancel</button>'
            document.getElementById("myTable").rows[i].cells[4].innerHTML = y2;
           
            
          

            break;
        }

    }

}
function clearItem(id) {

    for (let i = 0; i < myTable.rows.length; i++) {

        var x = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == x) {



            document.getElementById("myTable").rows[i].cells[4].innerHTML = "";
            var y2 = '<h6 style="margin-bottom:0">Delete?<h6><br/><button type="button" class="btn btn-primary" id="editAccountantID" onclick="ClearItem(' + x + ')">Yes</button> <button class="btn btn-primary" id="cancel" >No</button>'
            document.getElementById("myTable").rows[i].cells[4].innerHTML = y2;




            break;
        }
    }
}
function ClearItem(id)
{
    $.ajax({
        url: 'Items.aspx/DeleteItems',
        type: 'post',
        data: JSON.stringify({ "iD": id }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            debugger
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'itemID' },
                    { 'data': 'itemName' },
                    { 'data': 'costPrice' },
                    { 'data': 'salePrice' },
                    {
                        'data': 'itemID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editItem(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearItem(' + data + ')"><i class="fa fa-trash"></i></button>'
                        }
                    }
                ]
            });


        }

    });

}
function updateList(id) {
    var name = document.getElementById("inputName").value;
    var cost = document.getElementById("inputCost").value;
    var sale = document.getElementById("inputSale").value;
    $.ajax({
        url: 'Items.aspx/UpdatedItems',
        type: 'post',
        data: JSON.stringify({ "iD": id, "name": name,"cost":cost,"sale":sale }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            debugger
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'itemID' },
                    { 'data': 'itemName' },
                    { 'data': 'costPrice' },
                    { 'data': 'salePrice' },
                    {
                        'data': 'itemID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editItem(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearItem(' + data + ')"><i class="fa fa-trash"></i></button>'
                        }
                    }
                ]
            });


        }

    });

}
function displayDiv() {
    
        $("#addItem").fadeIn();
    
}
function hideDiv(){
    $("#addItem").fadeOut();
}
function addItem() {
    var ID = document.getElementById("newID").value;
    var name = document.getElementById("newName").value;
    var cost = document.getElementById("newCost").value;
    var sale = document.getElementById("newSale").value;
    $.ajax({
        url: 'Items.aspx/AddItems',
        type: 'post',
        data: JSON.stringify({ "iD": ID, "name": name, "cost": cost, "sale": sale }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            debugger
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'itemID' },
                    { 'data': 'itemName' },
                    { 'data': 'costPrice' },
                    { 'data': 'salePrice' },
                    {
                        'data': 'itemID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editItem(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearItem(' + data + ')"><i class="fa fa-trash-alt"></i></button>'
                        }
                    }
                ]
            });


        }

    });
}