﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
    public partial class Accountants : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != "admin")
            {
                Response.Redirect("MainPage.aspx");
            }
            
          
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("Login.aspx");
        }

       
        [WebMethod]
        public static string GetAccounts()
        {
            List<Accounts> list = (List<Accounts>)HttpContext.Current.Session["accounts"];
            

            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
        [WebMethod]
        public static string AddAccountant(string username,string password)
        {
            List<Accounts> list = (List<Accounts>)HttpContext.Current.Session["accounts"];
            int id = list.Count+1;
            Accounts newAccount = new Accounts(id,username, password);
            list.Add(newAccount);
            HttpContext.Current.Session["accounts"] = list;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
        [WebMethod]
        public static string DeleteAccountant(string id)
        {
            List<Accounts> list = (List<Accounts>)HttpContext.Current.Session["accounts"];
            int ID = Convert.ToInt32(id);
            for (int i = 0; i < list.Count;i++ )
            {
                if(list[i].ID==ID)
                {
                    list.RemoveAt(i);
                }
            }
            HttpContext.Current.Session["accounts"] = list;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
      
    }
}