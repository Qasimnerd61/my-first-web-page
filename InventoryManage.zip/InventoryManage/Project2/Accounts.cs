﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project2
{
    public class Accounts
    {
        public int ID { get; set; }
        public string userName { get; set; }
        public string password { get; set; }

        public Accounts(int id,string Name,string pass)
        {
            ID = id;
            userName = Name;
            password = pass;

        }
        
        public List<Accounts> getAccounts()
        {
            Accounts Admin = new Accounts(1,"admin", "admin");
            List<Accounts> Accounts = new List<Accounts>();
            Accounts.Add(Admin);
            return Accounts;
        }
    
    }

    
}