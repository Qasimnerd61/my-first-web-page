﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project2
{
    public class Invoice
    {

        public int ID { get; set; }
        public string customerName { get; set; }
        public string date { get; set; }
        public List<newItems> items { get; set; }

        public Invoice(int id, List<newItems> Items, string Name, string Date)
        {
            ID = id;
            customerName = Name;
            date = Date;
            items = Items;
        }

        public List<Invoice> GetInvoice()
        {
            newItems items = new newItems(90, "pen", 87, 90);
            List<newItems> itemList = items.getItems();
            List<Invoice> list = new List<Invoice>();
            Invoice b1 = new Invoice(1, itemList, "Shazil", "2022-07-19");
            list.Add(b1);
            return list;

        }


    }
    


}
    