﻿$(document).ready(function () {

    $.ajax({
        url: 'Accountants.aspx/GetAccounts',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (data) {
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'userName' },
                     { 'data': 'password' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            
                            return '<button type="button" class="btn btn-dark" id="deleteItem" onclick="AddDelAccountant('+1+',' + data + ')"><i class="fa fa-trash"></i></button>';
                            debugger
                        }
                    }
                    
                ]
            });
        }
    });
});
function AddDelAccountant(choice,id) {
    
    
    if (choice != 1)
    {
        var username = $("#username").val();
        var password = $("#password").val();
        if (username == "" || password == "") {
            $("#status_div").show();
            document.getElementById("Status").innerHTML = "All fields must be filled!";
            return false;
        }
        else {
            $("#status_div").show();
            document.getElementById("Status").innerHTML = "Accountant Added!";
            var link = 'Accountants.aspx/AddAccountant';
            var data = JSON.stringify({ "username": username, "password": password });
        }
    }
    else{
        var link = 'Accountants.aspx/DeleteAccountant';
        var data=JSON.stringify({"id":id});
    }
    $.ajax({
        url: link,
        method: 'post',
        dataType: 'json',
        data: data,
        contentType: 'application/json',
        async: false,
        success: function (data) {
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data' : 'ID'},
                    { 'data': 'userName' },
                     { 'data': 'password' },
                    {
                        'data': 'ID',
                        'render': function (data) {

                            return '<button type="button" class="btn btn-dark" onclick="AddDelAccountant('+1+' ,'+ data + ')"><i class="fa fa-trash"></i></button>';

                        }
                    }

                ]
            });
        }
    });
}
