﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
    public partial class Bills : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["user"]==null)
            {
                Response.Redirect("Login.aspx");
            }
            
            
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("Login.aspx");
        }

        [WebMethod]
        public static string GetCustomers()
        {
            List<Invoice> list = (List<Invoice>)HttpContext.Current.Session["Bill"];

            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
        [WebMethod]
        public static string AddItem(string id,string name)
        {
            List<Invoice> list = (List<Invoice>)HttpContext.Current.Session["Bill"];
            List<newItems> checkList = (List<newItems>)HttpContext.Current.Session["items"];
            int ID=Convert.ToInt32(id);
            for(int i=0;i<list.Count;i++)
            {
                if(ID==list[i].ID)
                {
                    for(int j=0;j<checkList.Count;j++)
                    {
                        if(name==checkList[j].itemName)
                        {
                            list[i].items.Add(checkList[j]);
                        }
                    }
                }
            }
            HttpContext.Current.Session["Bill"] = list;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
        [WebMethod]
        public static string ClearItem(string id, string name)
        {
            List<Invoice> list = (List<Invoice>)HttpContext.Current.Session["Bill"];
            
            int ID = Convert.ToInt32(id);
            for (int i = 0; i < list.Count; i++)
            {
                if (ID == list[i].ID)
                {
                    for(int j=0;j<list[i].items.Count;j++)
                    {
                        if(name==list[i].items[j].itemName)
                        {
                            list[i].items.RemoveAt(j);
                        }
                    }
                }
            }
            HttpContext.Current.Session["Bill"] = list;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
        [WebMethod]
        public static string UpdateInfo(string id, string name,string date)
        {
            List<Invoice> list = (List<Invoice>)HttpContext.Current.Session["Bill"];

            int ID = Convert.ToInt32(id);
            for (int i = 0; i < list.Count; i++)
            {
                if (ID == list[i].ID)
                {
                    if (name != "")
                    {
                        list[i].customerName = name;
                    }
                    if (date != "")
                    {
                        list[i].date = date;
                    }
                }
            }
            HttpContext.Current.Session["Bill"] = list;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
        [WebMethod]
        public static string ClearedBill(string id)
        {
            List<Invoice> list = (List<Invoice>)HttpContext.Current.Session["Bill"];

            int ID = Convert.ToInt32(id);
            for (int i = 0; i < list.Count; i++)
            {
                if (ID == list[i].ID)
                {
                    list.RemoveAt(i);
                }
            }
            HttpContext.Current.Session["Bill"] = list;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
        [WebMethod]
        public static string InsertBill(string id,string name,string date,string items)
        {
            int ID=Convert.ToInt32(id);
            List<newItems> checkList = (List<newItems>)HttpContext.Current.Session["items"];
            List<string> result = items.Split(',').ToList();
            List<Invoice> list = (List<Invoice>)HttpContext.Current.Session["Bill"];
            List<newItems> anyList = new List<newItems>();
            for (int i = 0; i < checkList.Count;i++ )
            {
                for (int j=0;j<result.Count;j++)
                {
                    if(checkList[i].itemName==result[j])
                    {
                        anyList.Add(checkList[i]);
                    }
                }
            }

            Invoice newInvoice = new Invoice(ID, anyList, name, date);

            list.Add(newInvoice);

            HttpContext.Current.Session["Bill"] = list;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
    }
    

}