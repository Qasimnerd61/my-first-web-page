﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project2
{
    public class Customer
    {
        
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }

        public Customer(int id,string name,string address)
        {
            ID=id;
            Name = name;
            Address = address;

        }
        
        public List<Customer> getCustomers()
        {
            List<Customer> Customers= new List<Customer>();
            Customer c1 = new Customer(1,"Shazil Anjum", "Khanewal");
            Customers.Add(c1);
            Customer c2 = new Customer(45, "Saad Anjum", "Abdul Hakim");
            Customers.Add(c2);
            Customer c3 = new Customer(87, "Ahsan Anjum", "Multan");
            Customers.Add(c3);
            Customer c4 = new Customer(21, "Uzair Anjum", "Lahore");
            Customers.Add(c4);
            Customer c5 = new Customer(15, "Furqan Sagheer", "Karachi");
            Customers.Add(c5);
            Customer c6 = new Customer(65, "Umer Gillani", "Mianwali");
            Customers.Add(c6);
            Customer c7 = new Customer(98, "Noraiz Shahid", "Kashmir");
            Customers.Add(c7);
            Customer c8 = new Customer(78, "Hussnain Liaqat", "Vehari");
            Customers.Add(c8);
            Customer c9 = new Customer(56, "Abdul Rehman", "Jhang");
            Customers.Add(c9);
            Customer c10 = new Customer(43, "Abu Bakar", "Gujranwala");
            Customers.Add(c10);
            Customer c11 = new Customer(28, "Qasim Raza", "Harbanspura");
            Customers.Add(c11);
            Customer c12 = new Customer(69, "Faiz Ahmed", "Sarghoda");
            Customers.Add(c12);
            return Customers;
        }
    }
}